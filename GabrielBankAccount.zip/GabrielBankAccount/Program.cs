﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace GabrielBankAccount
{
    public class Program
    {
        static void Main()
        {
            Account acc1 = new();
            Account acc2 = new();

            string next = "да";

            while (next != "нет")
            {
                Console.WriteLine("Выберите счёт:");
                Console.WriteLine("1");
                Console.WriteLine("2");
                Console.WriteLine();
                string choice = Console.ReadLine();
                Console.WriteLine();
                Console.WriteLine();

                Console.WriteLine("Выберите действие со счётом:");
                Console.WriteLine("1 - открытие счёта");
                Console.WriteLine("2 - вывод информации о счёте");
                Console.WriteLine("3 - внесение средств на счёт");
                Console.WriteLine("4 - снятие средств со счёта");
                Console.WriteLine("5 - обнуление счёта");
                Console.WriteLine("6 - транзакция");
                Console.WriteLine();
                choice += Console.ReadLine();
                Console.WriteLine();
                Console.WriteLine();

                switch (choice)
                {
                        case "11":
                        {
                            Console.ForegroundColor = ConsoleColor.Blue;
                            Console.Write("Введите номер счёта: ");
                            int nom = Convert.ToInt32(Console.ReadLine());
                            Console.Write("Введите ФИО владельца: ");
                            string name = Console.ReadLine();
                            Console.Write("Введите сумму: ");
                            double sum = Convert.ToDouble(Console.ReadLine());
                            acc1.Otk(nom, name, sum);
                            Console.ResetColor();
                            break;
                        }

                        case "12":
                        {
                            Console.ForegroundColor = ConsoleColor.Blue;
                            acc1.Out();
                            Console.ResetColor();
                            break;
                        }

                        case "13":
                        {
                            Console.ForegroundColor = ConsoleColor.Blue;
                            Console.Write("Введите сумму: ");
                            double sum = Convert.ToDouble(Console.ReadLine());
                            acc1.Dob(sum);
                            Console.ResetColor();
                            break;
                        }

                        case "14":
                        {
                            Console.ForegroundColor = ConsoleColor.Blue;
                            Console.Write("Введите сумму: ");
                            double sum = Convert.ToDouble(Console.ReadLine());
                            acc1.Umen(sum);
                            Console.ResetColor();
                            break;
                        }

                        case "15":
                        {
                            Console.ForegroundColor = ConsoleColor.Blue;
                            acc1.Obnul();
                            Console.ResetColor();
                            break;
                        }

                        case "16":
                        {
                            Console.ForegroundColor = ConsoleColor.Blue;
                            Console.Write("Введите сумму: ");
                            double sum = Convert.ToDouble(Console.ReadLine());
                            Console.Write("Введите номер счёта получателя: ");
                            int nom = Convert.ToInt32(Console.ReadLine());
                            if (acc2.AccSearch(nom) == 1)
                            {
                              acc1.Trans(sum, acc2);
                            }
                            Console.ResetColor();
                            break;
                        }

                        case "21":
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.Write("Введите номер счёта: ");
                            int nom = Convert.ToInt32(Console.ReadLine());
                            Console.Write("Введите ФИО владельца: ");
                            string name = Console.ReadLine();
                            Console.Write("Введите сумму: ");
                            double sum = Convert.ToDouble(Console.ReadLine());
                            acc2.Otk(nom, name, sum);
                            Console.ResetColor();
                            break;
                        }

                        case "22":
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            acc2.Out();
                            Console.ResetColor();
                            break;
                        }

                        case "23":
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.Write("Введите сумму: ");
                            double sum = Convert.ToDouble(Console.ReadLine());
                            acc2.Dob(sum);
                            Console.ResetColor();
                            break;
                        }

                        case "24":
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.Write("Введите сумму: ");
                            double sum = Convert.ToDouble(Console.ReadLine());
                            acc2.Umen(sum);
                            Console.ResetColor();
                            break;
                        }

                        case "25":
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            acc2.Obnul();
                            Console.ResetColor();
                            break;
                        }

                        case "26":
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.Write("Введите сумму: ");
                            double sum = Convert.ToDouble(Console.ReadLine());
                            Console.Write("Введите номер счёта получателя: ");
                            int nom = Convert.ToInt32(Console.ReadLine());
                            
                            if (acc1.AccSearch(nom) == 1)
                            {
                                acc2.Trans(sum, acc1);
                            }
                            Console.ResetColor();
                            break;
                        }
                }

                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine("Хотите продолжить?");
                next = Console.ReadLine();
                Console.WriteLine();
                Console.WriteLine();
            }
        }
    }
}