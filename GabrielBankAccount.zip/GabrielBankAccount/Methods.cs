﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GabrielBankAccount
{
    public class Account
    {
        private int nom; //номер счёта
        private string name; //ФИО владельца
        private double sum; //сумма на счету

        /// <summary>
        /// Открытие счёта
        /// </summary>
        /// <param name="nom"></param>
        /// <param name="name"></param>
        /// <param name="sum"></param>
        public void Otk(int nom, string name, double sum)
        {
            this.nom = nom;
            this.name = name;
            this.sum = Math.Round(sum,2);
            Console.WriteLine("Счёт создан.");
        }

        /// <summary>
        /// Вывод информации о счёте
        /// </summary>
        public void Out()
        {
            Console.WriteLine("Номер счёта: " + nom);
            Console.WriteLine("Владелец: " + name);
            Console.WriteLine("Сумма: " + sum);
        }

        /// <summary>
        /// Внесение средств на счёт
        /// </summary>
        /// <param name="sum"></param>
        public void Dob(double sum)
        {
            this.sum += Math.Round(sum);
            Console.WriteLine("Средства внесены.");
        }

        /// <summary>
        /// Снятие средств со счёта
        /// </summary>
        /// <param name="sum"></param>
        public void Umen(double sum)
        {
            if (sum <= this.sum)
            {
                this.sum -= Math.Round(sum);
                Console.WriteLine("Средства сняты.");
            }
            else
            {
                Console.WriteLine("Вы не можете снять больше средств, чем есть на счету.");
            }
            
        }

        /// <summary>
        /// Обнуление счёта
        /// </summary>
        public void Obnul()
        {
            this.sum = 0;
            Console.WriteLine("Счёт обнулён.");
        }

        /// <summary>
        /// Транзакция
        /// </summary>
        /// <param name="sum"></param>
        public void Trans(double sum, Account acc)
        {
            if (sum <= this.sum)
            {
                this.sum -= Math.Round(sum, 2);
                acc.sum += Math.Round(sum, 2);
                Console.WriteLine("Перевод доставлен.");
            }
            else
            {
                Console.WriteLine("Вы не можете перевести больше средств, чем есть на счету.");
            }        
        }

        /// <summary>
        /// Поиск счёта по номеру (сравнение введённого номера с номером конкретного счёта)
        /// </summary>
        /// <param name="nom"></param>
        /// <returns></returns>
        public int AccSearch(int nom)
        {
            if (nom == this.nom)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
    }
}
