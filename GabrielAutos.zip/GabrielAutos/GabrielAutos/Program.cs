﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Autos
{
	internal class Program
	{
		static void Main()
		{
			Avto A1 = new Avto();
			Avto A2 = new Avto();

			string next = "да";

			while (next != "нет")
			{
				Console.WriteLine("Выберите машину:");
				Console.WriteLine("1");
				Console.WriteLine("2");
				Console.WriteLine();
				string choice = Console.ReadLine();
				Console.WriteLine();
				Console.WriteLine();

				Console.WriteLine("Выберите действие с машиной:");
				Console.WriteLine("1 - ввод информации об авто");
				Console.WriteLine("2 - вывод информации об авто");
				Console.WriteLine("3 - заправка бензобака");
				Console.WriteLine("4 - поездка");
				Console.WriteLine("5 - расчёт количества возможных аварий");
				Console.WriteLine();
				choice += Console.ReadLine();
				Console.WriteLine();
				Console.WriteLine();

				switch (choice)
				{
						case "11":
						{
							Console.ForegroundColor = ConsoleColor.Blue;
							Console.Write("Введите номер авто: ");
							string nom = Console.ReadLine();
							Console.Write("Введите литраж бензобака: ");
							double bak = Convert.ToDouble(Console.ReadLine());
							Console.Write("Введите расход топлива на 100 км: ");
							double ras = Convert.ToDouble(Console.ReadLine());
							Console.Write("Введите пробег: ");
                            double prob = Convert.ToDouble(Console.ReadLine());
							Console.WriteLine();
							A1.InfoIn(nom, bak, ras, prob);
							Console.ResetColor();
							break;
						}

						case "12":
						{
							Console.ForegroundColor = ConsoleColor.Blue;
							A1.InfoOut();
							Console.ResetColor();
							break;
						}

						case "13":
						{
							Console.ForegroundColor = ConsoleColor.Blue;
							A1.Zapravka();
							Console.ResetColor();
							break;
						}

						case "14":
						{
							Console.ForegroundColor = ConsoleColor.Blue;
							Console.WriteLine("Введите координаты начала пути:");
							Console.Write("Введите x1: ");
                            double x1 = Convert.ToDouble(Console.ReadLine());
							Console.Write("Введите y1: ");
                            double y1 = Convert.ToDouble(Console.ReadLine());
							Console.WriteLine("Введите координаты конца пути:");
							Console.Write("Введите x2: ");
                            double x2 = Convert.ToDouble(Console.ReadLine());
							Console.Write("Введите y2: ");
                            double y2 = Convert.ToDouble(Console.ReadLine());
							Console.WriteLine();
							A1.Move(x1, y1, x2, y2);
							Console.ResetColor();
							break;
						}

						case "15":
						{
                            Console.ForegroundColor = ConsoleColor.Blue;
                            Console.Write("Введите номер авто, с траекторией которого хотите свериться: ");
                            string nom = Console.ReadLine();

                            if (A2.AvtoSearch(nom) == 1)
                            {
                                Console.WriteLine("Количество возможных аварий с участием этих машин: " + A1.Accident(A2));
                            }

                            Console.ResetColor();
                            break;
                        }

						case "21":
						{
							Console.ForegroundColor = ConsoleColor.Green;
							Console.Write("Введите номер авто: ");
							string nom = Console.ReadLine();
							Console.Write("Введите литраж бензобака: ");
                            double bak = Convert.ToDouble(Console.ReadLine());
							Console.Write("Введите расход топлива на 100 км: ");
                            double ras = Convert.ToDouble(Console.ReadLine());
							Console.Write("Введите пробег: ");
                            double prob = Convert.ToDouble(Console.ReadLine());
							Console.WriteLine();
							A2.InfoIn(nom, bak, ras, prob);
							Console.ResetColor();
							break;
						}

						case "22":
						{
							Console.ForegroundColor = ConsoleColor.Green;
							A2.InfoOut();
							Console.ResetColor();
							break;
						}

						case "23":
						{
							Console.ForegroundColor = ConsoleColor.Green;
							A2.Zapravka();
							Console.ResetColor();
							break;
						}

						case "24":
						{
							Console.ForegroundColor = ConsoleColor.Green;
							Console.WriteLine("Введите координаты начала пути:");
							Console.Write("Введите x1: ");
                            double x1 = Convert.ToDouble(Console.ReadLine());
							Console.Write("Введите y1: ");
                            double y1 = Convert.ToDouble(Console.ReadLine());
							Console.WriteLine("Введите координаты конца пути:");
							Console.Write("Введите x2: ");
                            double x2 = Convert.ToDouble(Console.ReadLine());
							Console.Write("Введите y2: ");
                            double y2 = Convert.ToDouble(Console.ReadLine());
							Console.WriteLine();
							A2.Move(x1, y1, x2, y2);
							Console.ResetColor();
							break;
						}

						case "25":
						{
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.Write("Введите номер авто, с траекторией которого хотите свериться: ");
                            string nom = Console.ReadLine();

                            if (A1.AvtoSearch(nom) == 1)
                            {
                                Console.WriteLine("Количество возможных аварий с участием этих машин: " + A2.Accident(A1));
                            }

                            Console.ResetColor();
                            break;
						}

				}

                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine("Хотите продолжить?");
				Console.WriteLine();
				next = Console.ReadLine();
				Console.WriteLine();
				Console.WriteLine();
			}
		}
	}
}